package JDBC;

public class Error {

	public boolean flag;
	
	public String message;

	public Error(boolean f, String msg) {
		
		this.flag = f;
		
		this.message = msg;
	}
}
