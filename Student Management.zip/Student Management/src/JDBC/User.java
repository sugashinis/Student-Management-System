package JDBC;

public class User {

	public static  int ID;
	
	public static String Name;
	
	public int getID() {
		
		return this.ID;
		
	}
	public String getName() {
		
		return this.Name;
		
	}
}
